# For Ammu — Birthday Diary Website

A responsive, no-backend birthday website built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and birthday letter
- `style.css` — vintage scrapbook styling and responsive layout
- `script.js` — games, diary chapters, files, envelopes, navigation, and finale

## Run locally
1. Keep all three files in the same folder.
2. Open `index.html` in a modern browser. Most features work directly from the file.
3. For a more realistic local test, use a simple static server such as VS Code's Live Server extension, or run `python -m http.server 8000` from this folder and visit `http://localhost:8000`.

## Publish free with GitHub Pages
1. Sign in or create a GitHub account.
2. Create a new repository, for example `ammu-birthday`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository's root (not inside another folder).
4. Open the repository's **Settings → Pages**.
5. Under the build/deployment section, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. Wait for GitHub Pages to finish deploying. The public URL will be shown in Settings → Pages, typically `https://YOUR-USERNAME.github.io/ammu-birthday/`.
8. Open that URL on your phone and test it before sharing.

GitHub Pages URLs are public to anyone who has the link and may be discoverable. `noindex` asks search engines not to index the page but does not guarantee privacy or prevent sharing. Do not add private information.

## Before sharing checklist
- [ ] Opening greeting appears on every visit.
- [ ] Answer all 3 opening questions and confirm the reveal appears.
- [ ] Open all 4 diary chapters and use previous/next/close controls.
- [ ] Open all 3 teacher files and close/reopen them.
- [ ] Complete the 7-question quiz, check the score, and replay.
- [ ] Open and close all 4 envelopes.
- [ ] Read the full letter and check the exact signature.
- [ ] Trigger the final animation and revisit the diary.
- [ ] Tap the tiny footer star for the Easter egg.
- [ ] Test on a phone in portrait mode and check text size, contrast, and button spacing.
- [ ] Confirm the public URL works in a private/incognito browser window.

## Notes
- No photographs, audio, analytics, tracking, login, database, or API key are included.
- Google Fonts are requested for typography; if the network is unavailable, system fallback fonts are used.
- No live URL has been created by this package. Publishing is a manual step.
