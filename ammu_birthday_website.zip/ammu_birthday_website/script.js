const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const screens = $$('.screen');
function go(id){
  const target = document.getElementById(id);
  if(!target) return;
  screens.forEach(s=>s.classList.toggle('active',s.id===id));
  $('#navLinks').classList.remove('open'); $('#menuButton').setAttribute('aria-expanded','false');
  window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  if(id==='finale') launchConfetti();
}
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
$('#menuButton').addEventListener('click',()=>{const open=$('#navLinks').classList.toggle('open');$('#menuButton').setAttribute('aria-expanded',String(open));});
let toastTimer;
function toast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2600)}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

// Opening mini-game: exactly three easy questions.
const openingQuestions=[
 {q:'What kind of day is this little website celebrating?',a:['A surprise birthday','A chemistry exam','A staff meeting'],correct:0,feedback:['Exactly! Birthday mode: activated. 🎂','Plot twist: it is birthday magic, not an exam. Try the next one!','No minutes of meeting today. Only birthday wishes. 😂']},
 {q:'What sort of things do we share in our conversations?',a:['College updates and random little things','Only weather reports','Official government paperwork'],correct:0,feedback:['Correct. The college updates department is open. ✉','Not quite — everyday college updates are more our vibe.','Imagine submitting a Ramsha–Zubiya report in triplicate. 😂']},
 {q:'In our secret code, who is “the Admin”?',a:['Talha Sir','Asim Sir','The website developer'],correct:1,feedback:['Close to the archive, but the Admin is Asim Sir!','Correct! Case-file knowledge detected. 🕵️','Honestly, the developer is just trying to keep the buttons working.']}
];
let openingIndex=0;
function renderOpening(){
 const q=openingQuestions[openingIndex];$('#openingCount').textContent=`QUESTION ${openingIndex+1} OF 3`;
 $('#openingProgress').style.width=`${openingIndex/3*100}%`;$('#openingQuestion').textContent=q.q;$('#openingFeedback').textContent='';$('#openingNext').disabled=true;
 $('#openingNext').textContent=openingIndex===2?'Reveal my surprise ✨':'Next little question →';
 const opts=$('#openingOptions');opts.innerHTML='';
 q.a.forEach((a,i)=>{const b=document.createElement('button');b.className='option';b.textContent=a;b.addEventListener('click',()=>{
  if(opts.dataset.answered==='yes')return;opts.dataset.answered='yes';$$('button',opts).forEach(x=>x.disabled=true);
  b.classList.add(i===q.correct?'correct':'incorrect');$('#openingFeedback').textContent=q.feedback[i];$('#openingNext').disabled=false;
 });opts.appendChild(b)});delete opts.dataset.answered;
}
$('#openingNext').addEventListener('click',()=>{if(openingIndex<2){openingIndex++;renderOpening()}else{go('reveal');$('#openingProgress').style.width='100%'}});
renderOpening();

// Diary chapters.
const chapters=[
 {label:'CHAPTER 01 • THE UNEXPECTED GOOD THING',title:'How This Year Surprised Me',body:`<p>I didn't necessarily expect this year to bring me someone I'd want to tell so many little things to. But somehow, it brought me you.</p><p>It wasn't one grand, movie-like moment. It's more the simple fact that you became someone I naturally think of when there is a college update, a random observation, or something I just feel like sharing.</p><p>Some people become important through the little things, quietly and without needing a big announcement. I'm genuinely glad this year brought you into my life. You turned out to be one of the best gifts this year brought me. ❤️</p>`},
 {label:'CHAPTER 02 • THE DAILY DISPATCHES',title:'Things I Always Tell You',body:`<p>College updates. Random observations. Opinions about things happening around us. And the updates you might have missed when you're absent. Basically, a tiny news channel with one very specific audience. 😂</p><p>Sometimes the thing itself is small, but it still feels worth telling you. I like that our conversations have room for all those ordinary details, not just big news or serious talks.</p><p>And naturally, no update feels complete without the occasional Ramsha–Zubiya discussion. The department is highly active and has absolutely no plans to retire.</p>`},
 {label:'CHAPTER 03 • THE CLASSIFIED CHRONICLES',title:'The Ramsha–Zubiya Chronicles',body:`<p>Welcome to the archive where two code names have somehow earned recurring roles in our conversations.</p><p><strong>RAMSHA</strong> = Talha Sir, Ameena's favourite chemistry teacher: talkative and known for on-the-spot replies.</p><p><strong>ZUBIYA</strong> = Asim Sir, my favourite teacher, otherwise known as “the Admin.”</p><p>Our research method? Talking about them. Our evidence? The fact that they keep becoming topics. Our official conclusion? This archive requires regular updates, but all case notes must remain respectful. 🕵️</p><p>For the full, highly unofficial report, visit the classified files section.</p>`},
 {label:'CHAPTER 04 • A PAGE OF GOOD WISHES',title:'Things I Hope for You',body:`<p>I hope this year brings you happiness that feels real, peace when life gets busy, and good health and well-being.</p><p>I hope you feel confident about the person you're becoming, find success in the goals that matter to you, and get chances to experience new and beautiful things.</p><p>I hope you give yourself room to learn, grow, rest, change your mind, and figure things out at your own pace. And most of all, I hope life gives you plenty of little reasons to smile — even on completely ordinary days.</p><p>Happy Birthday, Ammu. May this next chapter be kind to you. 🌷</p>`}
];
let chapterIndex=0;
function openChapter(i){chapterIndex=i;const c=chapters[i];$('#chapterLabel').textContent=c.label;$('#chapterTitle').textContent=c.title;$('#chapterBody').innerHTML=c.body;$('#chapterReader').classList.remove('hidden');$('#chapterReader').scrollIntoView({behavior:'smooth',block:'start'});$('#prevChapter').disabled=i===0;$('#nextChapter').textContent=i===3?'Back to diary ↑':'Next chapter →';}
$$('[data-chapter]').forEach(b=>b.addEventListener('click',()=>openChapter(Number(b.dataset.chapter))));
$('#closeChapter').addEventListener('click',()=>$('#chapterReader').classList.add('hidden'));
$('#prevChapter').addEventListener('click',()=>{if(chapterIndex>0)openChapter(chapterIndex-1)});
$('#nextChapter').addEventListener('click',()=>{if(chapterIndex<3)openChapter(chapterIndex+1);else $('#chapterReader').classList.add('hidden')});

// Interactive classified files.
const files=[
 {label:'FILE 01 • SUBJECT PROFILE',title:'RAMSHA: The Chemistry Conversation Starter',body:`<p><strong>Known identity:</strong> Talha Sir, Ameena's favourite chemistry teacher.</p><p><strong>Archive notes:</strong> Talkative. Often has an on-the-spot reply. Frequently mentioned in our conversations.</p><p><strong>Fictional case assessment:</strong> Conversation potential — HIGH. Chemistry-related mentions — unsurprising. Actual evidence of mischief — not required for this file.</p><p><strong>Case status:</strong> Permanently filed under “Things we end up discussing.”</p>`},
 {label:'FILE 02 • SUBJECT PROFILE',title:'ZUBIYA: The Admin',body:`<p><strong>Known identity:</strong> Asim Sir, my favourite teacher.</p><p><strong>Archive alias:</strong> “the Admin.”</p><p><strong>Fictional case assessment:</strong> Has achieved a memorable code name in our private joke system. Appears in conversation lore without needing an official invitation.</p><p><strong>Case status:</strong> Active in the archive. All commentary remains respectful; the nickname does the comedic work.</p>`},
 {label:'FILE 03 • PATTERN REVIEW',title:'The Ongoing Chronicles',body:`<p><strong>Question under review:</strong> How did these two teachers become recurring topics?</p><p><strong>Exhibit A:</strong> The code names Ramsha and Zubiya.</p><p><strong>Exhibit B:</strong> The fact that teacher discussions have their own dedicated archive on a birthday website.</p><p><strong>Exhibit C:</strong> This file itself. Very compelling evidence of recurring-topic energy.</p><p><strong>Final verdict:</strong> No real incident needs to be invented. The inside joke is already doing its job. File may be reopened whenever another harmless conversation inspires a new chapter. 😂</p>`}
];
function openFile(i){const f=files[i];$('#fileLabel').textContent=f.label;$('#fileTitle').textContent=f.title;$('#fileBody').innerHTML=f.body;$('#fileReader').classList.remove('hidden');$('#fileReader').scrollIntoView({behavior:'smooth',block:'start'});}
$$('[data-file]').forEach(b=>b.addEventListener('click',()=>openFile(Number(b.dataset.file))));
$('#closeFile').addEventListener('click',()=>$('#fileReader').classList.add('hidden'));

// Seven-question quiz with working score, progress and replay.
const quizQuestions=[
 {q:'Ramsha is the code name for…',a:['Talha Sir','Asim Sir','The college principal'],c:0,why:'Ramsha = Talha Sir, Ameena’s favourite chemistry teacher.'},
 {q:'And Zubiya is…',a:['Talha Sir','Asim Sir — “the Admin”','A secret flower code'],c:1,why:'Correct: Zubiya = Asim Sir, known as “the Admin.”'},
 {q:'What do our conversations often include?',a:['College updates and random observations','Only homework deadlines','Weather forecasts exclusively'],c:0,why:'Everyday updates and random little things are part of the lore.'},
 {q:'What happens when Ameena is absent from college?',a:['All updates are cancelled','I may share college updates with her','The college closes permanently'],c:1,why:'The college updates department continues its service. 😂'},
 {q:'What is the status of our friendship label?',a:['Officially declared best friends','A meaningful connection without forcing a label','A signed teacher contract'],c:1,why:'Exactly — meaningful does not need an official label.'},
 {q:'Which two names have their own classified archive here?',a:['Moon and Stars','Ramsha and Zubiya','Tea and Biscuits'],c:1,why:'The archive would like to thank its two recurring code names.'},
 {q:'What does the quiz score prove about the friendship?',a:['Everything about it','Absolutely nothing — it is just for fun','Who owes the other a chemistry lesson'],c:1,why:'Right! The score is a joke, not a measure of how much a connection matters.'}
];
let quizIndex=0,quizScore=0,quizAnswered=false;
function renderQuiz(){
 const q=quizQuestions[quizIndex];quizAnswered=false;$('#quizCount').textContent=`QUESTION ${quizIndex+1} OF 7`;$('#quizScore').textContent=`SCORE: ${quizScore}`;$('#quizProgress').style.width=`${quizIndex/7*100}%`;$('#quizQuestion').textContent=q.q;$('#quizFeedback').textContent='';$('#quizNext').disabled=true;$('#quizNext').textContent=quizIndex===6?'See my result →':'Next question →';$('#quizResult').classList.add('hidden');$('#quizQuestion').classList.remove('hidden');$('#quizOptions').classList.remove('hidden');$('#quizFeedback').classList.remove('hidden');$('#quizNext').classList.remove('hidden');
 const opts=$('#quizOptions');opts.innerHTML='';
 q.a.forEach((a,i)=>{const b=document.createElement('button');b.className='option';b.textContent=a;b.addEventListener('click',()=>{if(quizAnswered)return;quizAnswered=true;if(i===q.c)quizScore++;$$('button',opts).forEach(x=>x.disabled=true);b.classList.add(i===q.c?'correct':'incorrect');if(i!==q.c)$$('button',opts)[q.c].classList.add('correct');$('#quizScore').textContent=`SCORE: ${quizScore}`;$('#quizFeedback').textContent=(i===q.c?'Correct! ':'Not quite — ')+q.why;$('#quizNext').disabled=false;});opts.appendChild(b)});
}
function finishQuiz(){
 $('#quizProgress').style.width='100%';$('#quizCount').textContent='QUIZ COMPLETE';$('#quizQuestion').classList.add('hidden');$('#quizOptions').classList.add('hidden');$('#quizFeedback').classList.add('hidden');$('#quizNext').classList.add('hidden');$('#quizResult').classList.remove('hidden');
 let title,body;
 if(quizScore>=6){title='Certified Keeper of the Lore';body='The archive recognises your excellent knowledge of the very unofficial chronicles. 😂';}
 else if(quizScore>=4){title='Ramsha–Zubiya Expert';body='A respectable level of classified knowledge. The archive is pleased.';}
 else if(quizScore>=2){title='Official College Updates Department';body='Your department badge is ready. More conversations may be filed at any time.';}
 else{title='Ammu, Please Revise the Case Files 😂';body='A friendly reminder: this is a silly quiz, and you are still very much appreciated. Reopen the files or play again!';}
 $('#resultTitle').textContent=title;$('#resultText').textContent=`${body} Your score: ${quizScore}/7. The score is only for fun — it does not measure friendship.`;
}
$('#quizNext').addEventListener('click',()=>{if(!quizAnswered)return;if(quizIndex<6){quizIndex++;renderQuiz()}else finishQuiz()});
$('#replayQuiz').addEventListener('click',()=>{quizIndex=0;quizScore=0;renderQuiz()});
renderQuiz();

// Envelopes, each opens in an accessible modal and can be reopened.
const envelopes=[
 {eyebrow:'FILE SEALED • DO NOT TAKE TOO SERIOUSLY',title:'A Very Serious Investigation',body:`<p><strong>Confidential report:</strong> Two code names, multiple conversations, and an archive that now has its own birthday website.</p><p><strong>Subject A:</strong> Ramsha — talkative, on-the-spot replies, chemistry-teacher lore.</p><p><strong>Subject B:</strong> Zubiya — also known as “the Admin,” with a recurring role in the discussions.</p><p><strong>Conclusion:</strong> The evidence confirms an ongoing series of harmless conversations. Further research may be conducted over snacks, college updates, and an entirely reasonable amount of laughter. Case remains open. 😂</p>`},
 {eyebrow:'A NOTE OF APPRECIATION',title:'Things I Appreciate About You',body:`<p>I appreciate how naturally our conversations make room for everyday things — college updates, random thoughts, opinions, and the little details that might not seem important to anyone else.</p><p>I appreciate having someone I can share those things with, and I value the connection we've built through all those ordinary conversations. It doesn't need a big title to mean something.</p><p>I'm glad I got to know you, Ammu. That's a simple thing, but I mean it. ❤️</p>`},
 {eyebrow:'FOR A QUIET OR DIFFICULT DAY',title:'Open on a Difficult Day',body:`<p>Hey Ammu, if today feels heavy, you don't have to figure everything out all at once.</p><p>Take a breath, give yourself a little time, and remember that one difficult day does not define your whole story. You are allowed to rest. You are allowed to take things one step at a time. You deserve kindness — including from yourself.</p><p>You don't have to be cheerful every moment or have all the answers right now. I hope the day becomes gentler, and that you find comfort in small things and in people you trust.</p><p>Sending you a little reminder that happier days can still be ahead. 🌷</p>`},
 {eyebrow:'BIRTHDAY WISHES, SEALED WITH CARE',title:'Just for Your Birthday',body:`<p>Happy Birthday, Bibi Ameena! 🎂</p><p>I hope this new year of your life brings peaceful mornings, genuine laughter, good health and well-being, and success in the things you care about.</p><p>May you get opportunities that help you grow, experiences that make lovely stories, and enough calm moments to enjoy where you are right now. I hope you feel appreciated today — and on the ordinary days after your birthday, too.</p><p>Have the sweetest day, Ammu. ❤️</p>`}
];
function openModal(item){$('#modalEyebrow').textContent=item.eyebrow;$('#modalTitle').textContent=item.title;$('#modalBody').innerHTML=item.body;$('#modal').classList.remove('hidden');document.body.style.overflow='hidden';$('[data-close-modal]',$('#modal')).focus?.()}
function closeModal(){$('#modal').classList.add('hidden');document.body.style.overflow='';}
$$('[data-envelope]').forEach(b=>b.addEventListener('click',()=>openModal(envelopes[Number(b.dataset.envelope)])));
$$('[data-close-modal]').forEach(b=>b.addEventListener('click',closeModal));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#modal').classList.contains('hidden'))closeModal()});

// Finale and tasteful lightweight confetti.
let confettiLaunched=false;
function launchConfetti(){if(confettiLaunched)return;confettiLaunched=true;const c=$('#confetti');for(let i=0;i<34;i++){const p=document.createElement('i');p.className='confetti-piece';p.style.left=(Math.random()*100)+'%';p.style.animationDelay=(Math.random()*1.5)+'s';p.style.animationDuration=(2.6+Math.random()*2)+'s';p.style.transform=`rotate(${Math.random()*180}deg)`;c.appendChild(p)}}
$('#finalRevealButton').addEventListener('click',()=>{confettiLaunched=false;$('#confetti').innerHTML='';go('finale')});
$('#tinyStar').addEventListener('click',()=>toast('Tiny secret: you turned out to be one of the best gifts this year brought me. ❤️'));
let secretStampClicks=0;
$$('.stamp').forEach(s=>s.addEventListener('click',e=>{e.stopPropagation();secretStampClicks++;if(secretStampClicks%2===0)toast('BONUS FILE: The archive confirms that birthday cake is classified as essential research material. 🎂');else toast('Stamp recognised. Tap a file card to read the official unofficial report.');}));
